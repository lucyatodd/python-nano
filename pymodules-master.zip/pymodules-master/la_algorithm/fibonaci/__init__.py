"""
Collection of fibonacci methods and functions
"""

from . import goldenratio

__all__ = [
    'goldenratio'
]
